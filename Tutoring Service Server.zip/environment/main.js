const r = require("rethinkdb");
const http = require("http");
const User = require(__dirname+"/Classes/User.js");

const createAccount = async (username, password, c) =>
{
    let newAccount = new User(username, password);
    try
    {
        await r.table("Users").insert(newAccount).run(c);
    }
    catch(e)
    {
        return null;
    }
    return newAccount;
};

const main = async () =>
{
    const c = await r.connect({db: "Users"});
    http.createServer( (request, response) =>
        {
            let account;
            request.on("data", (data) => 
            {
                let args = data.split(" ");
                if(args[0]=="newAccount")
                {
                    account = createAccount(args[1], args[2], c);
                    console.log((account ? "Unsuccesfully" : "Succesfully") + " created account with username: " + args[1] + " and password: " + args[2]);
                }
            }).on("end", () =>
            {
                response.end(account);
            });
        }).listen(8080);
};

main();