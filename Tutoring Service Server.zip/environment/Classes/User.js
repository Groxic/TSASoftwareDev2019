const Student = require(__dirname+"/Student.js");
const Tutor = require(__dirname+"/Tutor.js");
module.exports = class User
{
    constructor(username, password, isTutor)
    {
        this.username = username;
        this.password = password;
        this.account = isTutor ? new Tutor() : new Student();
    }
};