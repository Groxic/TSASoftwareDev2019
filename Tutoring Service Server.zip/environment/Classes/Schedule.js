module.exports = class Schedule
{
    constructor()
    {
        this.days = [];
        this.times = [];
    }
};