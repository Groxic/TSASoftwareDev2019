const Schedule = require(__dirname+"/Schedule.js");
module.exports = class Tutor
{
    constructor()
    {
        this.location;
        this.schedule = new Schedule();
        this.bio;
    }
};