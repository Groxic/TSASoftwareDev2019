module.exports = class Student
{
    constructor()
    {
        this.location;
        this.bio;
    }
};